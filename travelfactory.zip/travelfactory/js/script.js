const delete_card = (e) => {
 e.parentNode.parentNode.parentNode.parentNode.remove();
}   

const edit_card = (e) => {
    e.parentNode.parentNode.parentNode.setAttribute('contenteditable', true); 
    e.parentNode.parentNode.parentNode.style.border ='2px dashed gray';
}

const edit_no_valid = (e) => {
    var reg = new RegExp(/^\d+(-\d+)*$/);
    if(!reg.test(e.children[0].children[1].children[0].children[5].children[0].innerHTML)){
        e.style.border = '2px solid red'; 
    }else{
        e.setAttribute('contenteditable', false); 
        e.style.border = 'none';
        
       }

}


let add_card = () => {
    const plus = document.querySelector('#plusBtn');
    const cards_container = document.getElementById("cards_container");

    let newCard = document.createElement('div');
    newCard.classList.add('col-lg-4');
    cards_container.appendChild(newCard);
    plus.before(newCard)
    newCard.innerHTML = `<div class="card mb-3" contenteditable="false" onfocusout="edit_no_valid(this)">
        <div class="row g-0">
          <div class="col-4">
            <img src="./img/alex jonathan.jpg" alt="janeth" class="img">
            <div class="text-center pt-5">Graphics designer</div>
          </div>
          
          <div class="col-8">
            <div class="card-body">
              <h5 class="card-title">Jhon Smith</h5>
              <p class="address"></p>
              <b class="card-text">Twitter. Inc.</b>
              <div class="card-text"><small class="text-muted">795 Folsom Ave, suite 600 </small></div>
              <div class="card-text"><small class="text-muted">San Francisco CA 94107</small></div>
              <div class="card-text"><small class="text-muted">123-456-7890</small></div>
            </div>
          </div>
        </div>
        <div class="row icons">
            <div class="edit col-3"><i class="fa fa-pencil" onclick="edit_card(this)"></i></div>
            <div class="delete col-3"><i class="fa fa-trash" onclick="delete_card(this)"></i></div>
        </div>
      </div>`;
      addresApi()
}

    
const addresApi = async () => {
    const response = await fetch('https://maps.googleapis.com/maps/api/geocode/json?address=paris&key=AIzaSyBGXoRK_gnTlj9WCrY2jtZyE74j2RPhgAs');
    const myJson = await response.json();
    console.log(myJson.results);
    const {lng,lat} = myJson.results[0].geometry.location;
    const adrress = document.querySelectorAll(".address");
    adrress.forEach( el => {
        el.innerHTML = Math.floor(lat) + '/' + Math.floor(lng)
    })
  }
  addresApi()